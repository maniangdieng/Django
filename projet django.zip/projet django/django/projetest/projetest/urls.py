

from django.contrib import admin
from django.urls import path, include
from eureka import views 
# urls.py
from django.conf import settings
from django.conf.urls.static import static

# ...


urlpatterns = [
    path('admin/', admin.site.urls),
    path('acceuil/', views.acceuil,name='acceuil'),
    path('python/', views.python, name='python'),
    path('apprendre_django/', views.apprendre_django,name='apprendre_django'),
    path('tutoriel/', views.tutoriel,name='tutoriel'),
    path('home/',views.home,name='home'),
    path('contact/',views.contact,name='contact'),
    path('inscription/', views.inscription, name='inscription'),
    path('send_message/',views.send_message,name='send_message'),
    path('acceuil/python.html', views.python, name='python'),
    path('acceuil/apprendre_django.html', views.apprendre_django,name='apprendre_django'),
    path('acceuil/tutoriel.html',views.tutoriel,name='tutoriel'),
    path('acceuil/contact.html',views.contact,name='contact'),
    path('lecon/<int:lecon_id>/', views.afficher_lecon, name='afficher_lecon'),
    path('python/<int:leconId>/', views.get_lecon, name='get_lecon'),
    path('apprendre_django/<int:lecon2Id>/', views.get_lecon2, name='get_lecon2'),
    path('get_videos/', views.get_videos, name='get_videos'),

]