
from django.db import models
from django.db import models
from django.db import models
from django.db import models
from django.db import models


class PDFFile(models.Model):
    title = models.CharField(max_length=255)
    pdf = models.FileField(upload_to='pdfs/')
    
from django.db import models


class Inscription(models.Model):
    nom = models.CharField(max_length=255)
    email = models.EmailField()

    def __str__(self):
        return self.nom



class Message(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    message = models.TextField()

    def __str__(self):
        return self.name
    
    from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Message

def send_message(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')

        if name and email and message:
            Message.objects.create(name=name, email=email, message=message)
            messages.success(request, 'Votre message a été envoyé avec succès.')
            return redirect('acceuil')  # Redirection vers la page d'accueil après l'envoi

    return render(request, 'eureka/contact.html')



class Lecon(models.Model):
    titre = models.CharField(max_length=200)
    contenu = models.TextField()
    date_creation = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.titre


class Lecon2(models.Model):
    titre = models.CharField(max_length=200)
    contenu = models.TextField()
    date_creation = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.titre
 

from django.db import models

class Video(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    video_url = models.URLField()

    def __str__(self):
        return self.title

