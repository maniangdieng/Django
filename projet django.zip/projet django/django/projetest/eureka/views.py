from django.shortcuts import render
from django.http import HttpResponse
# ~/projects/django-web-app/merchex/listings/views.py

from django.shortcuts import render, redirect


from django.contrib.auth import login


def acceuil (request):
     return render(request, 'eureka/acceuil.html')

def python(request):
    return render(request, 'eureka/python.html')

def apprendre_django(request):
     return render(request, 'eureka/apprendre_django.html')
def tutoriel(request):
     return render(request, 'eureka/tutoriel.html')
def home(request):
     return render(request, 'eureka/home.html')
def contact(request):
     return render(request, 'eureka/contact.html')

from django.shortcuts import render, redirect

from .models import Inscription

from django.shortcuts import render, redirect
from .models import Inscription

def inscription(request):
    if request.method == 'POST':
        nom = request.POST.get('nom')
        email = request.POST.get('email')
        # Traitez les données comme vous le souhaitez, par exemple, enregistrez-les dans la base de données
        inscription = Inscription(nom=nom, email=email)
        inscription.save()
          # Redirigez vers une page de confirmation d'inscription
    return render(request, 'eureka/acceuil.html')


from django.contrib import messages

from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Message

def send_message(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')

        if name and email and message:
            Message.objects.create(name=name, email=email, message=message)
            messages.success(request, 'Votre message a été envoyé avec succès.')
            return redirect('acceuil')  # Redirection vers la page d'accueil après l'envoi

    return render(request, 'eureka/contact.html')


from .models import Lecon

def afficher_lecon(request, leconId):
    lecon = Lecon.objects.get(pk=leconId)
    return render(request, 'eureka/python.html', {'lecon': lecon, 'titre_lecon': lecon.titre})

from django.http import JsonResponse

def get_lecon(request, leconId):
    try:
        lecon = Lecon.objects.get(id=leconId)
        lecon_data = {
            'titre': lecon.titre,
            'contenu': lecon.contenu,
        }
        return JsonResponse(lecon_data)
    except Lecon.DoesNotExist:
        return JsonResponse({'error': 'La leçon demandée n\'existe pas.'}, status=404)



from .models import Lecon2

def afficher_lecon2(request, leconId):
    lecon2 = Lecon2.objects.get(pk=leconId)
    return render(request, 'eureka/apprendre_django.html', {'lecon': lecon})

from django.http import JsonResponse

def get_lecon2(request, lecon2Id):
    try:
        lecon2 = Lecon2.objects.get(id=lecon2Id)
        lecon2_data = {
            'titre': lecon2.titre,
            'contenu': lecon2.contenu,
        }
        return JsonResponse(lecon2_data)
    except Lecon.DoesNotExist:
        return JsonResponse({'error': 'La leçon demandée n\'existe pas.'}, status=404)


#
from django.http import JsonResponse
from .models import Video


# Dans views.py
from django.shortcuts import render
from django.http import JsonResponse
from .models import Video

def get_videos(request):
    videos = Video.objects.all().values('title', 'description', 'video_url')
    video_data = list(videos)  # Convertir les vidéos en liste de dictionnaires
    return JsonResponse({'videos': video_data})
