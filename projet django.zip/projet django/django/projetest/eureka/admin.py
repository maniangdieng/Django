
from django.contrib import admin
from .models import PDFFile
from .models import Message
from .models import Inscription
from .models import Lecon
from .models import Lecon2
from .models import Video

admin.site.register(Message)
admin.site.register(Inscription)
admin.site.register(Lecon2)
admin.site.register(Lecon)
admin.site.register(PDFFile)
admin.site.register(Video)
# Register your models here.
